package io.gitlab.icestom.icestom_mod.mixin;

import io.gitlab.icestom.icestom_mod.IceStomModClient;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
   @Inject(
      method = "close",
      at = @At("RETURN")
   )
   private void onGameRendererClose(CallbackInfo ci) {
      IceStomModClient.getInstance().closePipelines();
   }
}
